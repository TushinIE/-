
jQuery(document).ready(function() {
	
    /*
        Fullscreen background
    */
    $('.top-content').backstretch("assets/img/backgrounds/1.jpg");
    $('.single-feature-bg').backstretch("assets/img/backgrounds/1.jpg");
    
});

